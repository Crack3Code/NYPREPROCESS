addpath(genpath('mat'));
addpath(genpath('utils'));
addpath(genpath('toolbox_nyu_depth_v2'));

rawdata_2_video(5, 5, 1)
